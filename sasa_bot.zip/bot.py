import logging
import os
from aiogram import Bot, Dispatcher, types
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils import executor

# تفعيل اللوج
logging.basicConfig(level=logging.INFO)

# إعدادات
TOKEN = os.getenv("TELEGRAM_TOKEN")
ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "admin")

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)

# ترحيب أول مرة
@dp.message_handler(commands=["start"])
async def start_message(message: types.Message):
    keyboard = InlineKeyboardMarkup().add(
        InlineKeyboardButton("✅ أوافق", callback_data="agree")
    )
    await message.answer(
        "أهلاً! أنا صاصا 😎\n\n"
        "قبل مانبدأ لازم توافق إنك *مش هتستخدم البوت في الغش* 🚫📚\n",
        reply_markup=keyboard,
        parse_mode="Markdown"
    )

# زر الموافقة
@dp.callback_query_handler(lambda c: c.data == "agree")
async def agree_callback(callback_query: types.CallbackQuery):
    await callback_query.message.answer(
        "تمام يا معلم ✅\n"
        "إسألني أي سؤال نص وأنا هجاوبك بطريقتي 😎"
    )

# رد افتراضي
@dp.message_handler()
async def reply_message(message: types.Message):
    if message.from_user.username == ADMIN_USERNAME:
        if message.text == "/stats":
            await message.answer("📊 لسه الإحصائيات مش متوصلة يا أدمن ✌️")
            return
    await message.answer("أنا صاصا 😎 ولسه شغال على Render، إسألني أي حاجة!")

if __name__ == "__main__":
    executor.start_polling(dp, skip_updates=True)
